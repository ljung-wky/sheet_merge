# -*- ecoding: utf-8 -*-
# @ModuleName: concat
# @Function: 
# @Author: Ljung_zhang
# @Time: 2021/7/9 下午12:07
from openpyxl import *
import openpyxl
import codecs
import os

source_pth = './shili.xlsx'
target_pth = './result.xlsx'
#加载excel
wb = load_workbook(source_pth)
#获取sheet名字表单
sheet_name = wb.get_sheet_names()
#将sheet名字单独存储维一个变量
data1 = []
for i in range(0,len(sheet_name)):
    get_each = wb.get_sheet_by_name(sheet_name[i])
    count_rows = get_each.max_row
    for j in range(count_rows):
        data1.append("UPSERT INTO APEX." + sheet_name[i] + " VALUES")
# 加载sheet_name所有内容
data = []
for i in range(0,len(sheet_name)):
    rewb=wb.get_sheet_by_name(sheet_name[i])
    rows=rewb.max_row
    for j in range(1,rows+1):
        data.append(rewb[j])
# # # #aoming
 # 写入数据
book= openpyxl.Workbook()
sh=book.active
sh.title="合并"
for i in range(1,len(data)+1):
    for j in range(1,len(data[i-1])+1):
        sh.cell(i, j, data[i-1][j-1].value)
book.save(target_pth)
filename=r'./result.xlsx'
dataxls = openpyxl.load_workbook(filename)
sheetnames = dataxls.get_sheet_names()
ws = dataxls.get_sheet_by_name(sheetnames[0])
rows = ws.max_row
f = codecs.open('./result.txt', 'w')
for row in range(1, rows+1):
    # row = table.row_values(ronum)
    sql_query = ""
    cols = 1
    while (ws.cell(row, cols).value!=None):
        while (ws.cell(row, cols + 1).value !=None):
            if cols == 1:
                sql_query = sql_query + "%s" % (data1[row-1]) + "(\'" + str(ws.cell(row, cols).value) + "\',"
            else:
                # 使用“，”逗号作为分隔符
                sql_query = sql_query + "\'%s\'" % (str(ws.cell(row, cols).value)) + ","
            cols = cols + 1;
        sql_query = sql_query + "\'%s\'" % (str(ws.cell(row, cols).value)) + ");"
        cols = cols + 1
    print(sql_query)
    f.write(sql_query)
    f.write('\r\n')
f.close()
# #     sql_file.write(sql_query)
# #     sql_file.write('\r\n')
# # sql_file.close()
